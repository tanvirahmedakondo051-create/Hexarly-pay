# Keep Room entities
-keep class com.hexarlypay.app.data.local.** { *; }

# Keep Gson / Retrofit models
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
