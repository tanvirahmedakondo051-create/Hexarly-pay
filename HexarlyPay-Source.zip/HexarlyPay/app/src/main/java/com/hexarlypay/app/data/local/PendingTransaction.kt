package com.hexarlypay.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pending_transactions")
data class PendingTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val provider: String,          // bkash, nagad, rocket...
    val amount: String,
    val trxId: String? = null,
    val rawSms: String,
    val type: String,              // IN or OUT
    val balance: String? = null,
    val counterparty: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = STATUS_PENDING, // PENDING, SYNCING, SUCCESS, FAILED
    val retryCount: Int = 0,
    val lastError: String? = null
) {
    companion object {
        const val STATUS_PENDING = "PENDING"
        const val STATUS_SYNCING = "SYNCING"
        const val STATUS_SUCCESS = "SUCCESS"
        const val STATUS_FAILED = "FAILED"
    }
}
