package com.hexarlypay.app.worker

import android.app.Notification
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.hexarlypay.app.R
import com.hexarlypay.app.data.repository.TransactionRepository
import java.util.concurrent.TimeUnit

class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repo = TransactionRepository.getInstance(applicationContext)
        val pending = repo.getPending()

        if (pending.isEmpty()) {
            repo.clearOldSuccess()
            return Result.success()
        }

        // Show low-priority foreground notification only while syncing
        setForeground(createForegroundInfo(pending.size))

        var anySuccess = false
        for (tx in pending) {
            if (tx.retryCount >= 8) continue // give up after too many failures
            val ok = repo.syncOne(tx)
            if (ok) anySuccess = true
        }

        repo.clearOldSuccess()
        return if (anySuccess) Result.success() else Result.retry()
    }

    private fun createForegroundInfo(count: Int): ForegroundInfo {
        val notification: Notification = NotificationCompat.Builder(applicationContext, "hexarly_sync")
            .setContentTitle("Hexarly Pay")
            .setContentText("Syncing $count transaction(s)...")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            ForegroundInfo(1001, notification)
        }
    }

    companion object {
        private const val UNIQUE_PERIODIC = "hexarly_periodic_sync"
        private const val UNIQUE_IMMEDIATE = "hexarly_immediate_sync"

        fun enqueueImmediate(context: Context) {
            val request = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 20, TimeUnit.SECONDS)
                .addTag("sync")
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork(UNIQUE_IMMEDIATE, ExistingWorkPolicy.REPLACE, request)
        }

        fun enqueuePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag("sync")
                .build()

            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(
                    UNIQUE_PERIODIC,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
        }
    }
}
