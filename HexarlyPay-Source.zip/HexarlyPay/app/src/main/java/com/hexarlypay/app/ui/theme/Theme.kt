package com.hexarlypay.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Hexarly Pay brand colors (deep blue from logo)
private val HexarlyBlue = Color(0xFF1A237E)
private val HexarlyBlueLight = Color(0xFF3949AB)
private val HexarlyBlueDark = Color(0xFF0D1B4C)

private val LightColorScheme = lightColorScheme(
    primary = HexarlyBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8EAF6),
    onPrimaryContainer = HexarlyBlueDark,
    secondary = HexarlyBlueLight,
    background = Color(0xFFF8F9FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFF0F2F8),
    onSurface = Color(0xFF1A1C1E),
    onSurfaceVariant = Color(0xFF44474E),
    outline = Color(0xFFC5C6D0)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF9FA8DA),
    onPrimary = HexarlyBlueDark,
    primaryContainer = HexarlyBlue,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFF9FA8DA),
    background = Color(0xFF12141A),
    surface = Color(0xFF1C1E26),
    surfaceVariant = Color(0xFF2A2D38),
    onSurface = Color(0xFFE3E2E6),
    onSurfaceVariant = Color(0xFFC5C6D0),
    outline = Color(0xFF8E9099)
)

@Composable
fun HexarlyPayTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}
