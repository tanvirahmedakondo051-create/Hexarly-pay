package com.hexarlypay.app.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import java.util.regex.Pattern

data class ProviderConfig(
    val id: String,
    val name: String,
    val senders: List<String>,
    val incoming: String,
    val outgoing: String,
    val amount: String,
    val trx: String,
    val balance: String? = null,
    val counterparty: String? = null,
    val beta: Boolean = false
)

data class ProvidersFile(
    val version: Int,
    val providers: List<ProviderConfig>
)

data class ParsedSms(
    val id: String,
    val name: String,
    val amount: String,
    val trxId: String?,
    val type: String,          // IN or OUT
    val balance: String?,
    val counterparty: String?
)

object ProviderParser {

    private var configs: List<ProviderConfig> = emptyList()
    private val amountPatterns = mutableMapOf<String, Pattern>()
    private val trxPatterns = mutableMapOf<String, Pattern>()
    private val balancePatterns = mutableMapOf<String, Pattern>()
    private val counterpartyPatterns = mutableMapOf<String, Pattern>()
    private val incomingPatterns = mutableMapOf<String, Pattern>()
    private val outgoingPatterns = mutableMapOf<String, Pattern>()

    fun init(context: Context) {
        if (configs.isNotEmpty()) return
        try {
            val json = context.assets.open("providers.json").bufferedReader().use { it.readText() }
            val file = Gson().fromJson(json, ProvidersFile::class.java)
            configs = file.providers

            // Pre-compile all regex (very important for performance)
            configs.forEach { p ->
                amountPatterns[p.id] = Pattern.compile(p.amount)
                trxPatterns[p.id] = Pattern.compile(p.trx)
                incomingPatterns[p.id] = Pattern.compile(p.incoming)
                outgoingPatterns[p.id] = Pattern.compile(p.outgoing)
                p.balance?.let { balancePatterns[p.id] = Pattern.compile(it) }
                p.counterparty?.let { counterpartyPatterns[p.id] = Pattern.compile(it) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun match(sender: String, body: String): ParsedSms? {
        if (configs.isEmpty()) return null

        val cleanSender = sender.replace("+88", "").trim()

        for (p in configs) {
            val senderMatch = p.senders.any { s ->
                cleanSender.contains(s, ignoreCase = true) ||
                        sender.contains(s, ignoreCase = true)
            }
            if (!senderMatch) continue

            val isIncoming = incomingPatterns[p.id]?.matcher(body)?.find() == true
            val isOutgoing = outgoingPatterns[p.id]?.matcher(body)?.find() == true

            if (!isIncoming && !isOutgoing) continue

            val amount = extract(amountPatterns[p.id], body) ?: continue
            val trxId = extract(trxPatterns[p.id], body)
            val balance = extract(balancePatterns[p.id], body)
            val counterparty = extract(counterpartyPatterns[p.id], body)

            return ParsedSms(
                id = p.id,
                name = p.name,
                amount = amount.replace(",", ""),
                trxId = trxId,
                type = if (isIncoming) "IN" else "OUT",
                balance = balance?.replace(",", ""),
                counterparty = counterparty
            )
        }
        return null
    }

    private fun extract(pattern: Pattern?, text: String): String? {
        if (pattern == null) return null
        val m = pattern.matcher(text)
        return if (m.find()) m.group(1) else null
    }
}
