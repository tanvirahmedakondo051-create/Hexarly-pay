package com.hexarlypay.app.util

import android.content.Context
import android.content.SharedPreferences

class PreferenceHelper(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hexarly_prefs", Context.MODE_PRIVATE)

    fun setApiKey(key: String) {
        prefs.edit().putString("api_key", key.trim()).apply()
    }

    fun getApiKey(): String? = prefs.getString("api_key", null)

    fun hasApiKey(): Boolean = !getApiKey().isNullOrBlank()

    fun setOnboardingDone() {
        prefs.edit().putBoolean("onboarding_done", true).apply()
    }

    fun isOnboardingDone(): Boolean = prefs.getBoolean("onboarding_done", false)

    fun setSmsPermissionGranted(granted: Boolean) {
        prefs.edit().putBoolean("sms_permission", granted).apply()
    }

    fun isSmsPermissionGranted(): Boolean = prefs.getBoolean("sms_permission", false)
}
