package com.hexarlypay.app.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

data class SyncRequest(
    val provider: String,
    val amount: String,
    val trx_id: String?,
    val type: String,
    val balance: String?,
    val counterparty: String?,
    val raw_sms: String,
    val timestamp: Long
)

data class SyncResponse(
    val success: Boolean,
    val message: String? = null
)

interface ApiService {
    @POST("api/v1/transactions/sync")
    suspend fun syncTransaction(
        @Header("X-API-Key") apiKey: String,
        @Body body: SyncRequest
    ): Response<SyncResponse>
}
