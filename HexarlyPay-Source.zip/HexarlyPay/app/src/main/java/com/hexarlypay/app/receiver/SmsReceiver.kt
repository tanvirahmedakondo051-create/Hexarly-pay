package com.hexarlypay.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Telephony
import com.hexarlypay.app.data.repository.TransactionRepository
import com.hexarlypay.app.util.ProviderParser
import com.hexarlypay.app.worker.SyncWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Extremely lightweight SMS Receiver.
 * - Only processes matching MFS providers (bKash, Nagad, Rocket etc.)
 * - Does zero network work on main thread
 * - Inserts into Room then triggers WorkManager if online
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        // Make sure providers are loaded
        ProviderParser.init(context)

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (messages.isEmpty()) return

        val sender = messages[0].originatingAddress ?: return
        val body = messages.joinToString(separator = "") { it.messageBody ?: "" }

        // Fast reject if not a known provider
        val parsed = ProviderParser.match(sender, body) ?: return

        // Go async so we don't block the broadcast
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = TransactionRepository.getInstance(context)
                repo.insertPending(
                    provider = parsed.id,
                    amount = parsed.amount,
                    trxId = parsed.trxId,
                    rawSms = body,
                    type = parsed.type,
                    balance = parsed.balance,
                    counterparty = parsed.counterparty
                )

                // If internet is available → trigger immediate sync
                if (isOnline(context)) {
                    SyncWorker.enqueueImmediate(context)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
