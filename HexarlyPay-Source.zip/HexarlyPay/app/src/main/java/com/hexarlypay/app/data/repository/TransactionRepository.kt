package com.hexarlypay.app.data.repository

import android.content.Context
import com.hexarlypay.app.data.local.AppDatabase
import com.hexarlypay.app.data.local.PendingTransaction
import com.hexarlypay.app.data.remote.ApiService
import com.hexarlypay.app.data.remote.SyncRequest
import com.hexarlypay.app.util.PreferenceHelper
import kotlinx.coroutines.flow.Flow
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class TransactionRepository private constructor(context: Context) {

    private val dao = AppDatabase.getInstance(context).transactionDao()
    private val prefs = PreferenceHelper(context)

    private val api: ApiService by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        Retrofit.Builder()
            .baseUrl("https://hexaarlypay.xyz/")   // <-- Your website
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    suspend fun insertPending(
        provider: String,
        amount: String,
        trxId: String?,
        rawSms: String,
        type: String,
        balance: String?,
        counterparty: String? = null
    ) {
        val tx = PendingTransaction(
            provider = provider,
            amount = amount,
            trxId = trxId,
            rawSms = rawSms,
            type = type,
            balance = balance,
            counterparty = counterparty
        )
        dao.insert(tx)
    }

    suspend fun getPending(): List<PendingTransaction> = dao.getPending()

    fun getRecentFlow(): Flow<List<PendingTransaction>> = dao.getRecentFlow()

    fun pendingCountFlow(): Flow<Int> = dao.pendingCountFlow()

    suspend fun syncOne(tx: PendingTransaction): Boolean {
        val apiKey = prefs.getApiKey() ?: return false
        return try {
            dao.updateStatus(tx.id, PendingTransaction.STATUS_SYNCING)
            val response = api.syncTransaction(
                apiKey = apiKey,
                body = SyncRequest(
                    provider = tx.provider,
                    amount = tx.amount,
                    trx_id = tx.trxId,
                    type = tx.type,
                    balance = tx.balance,
                    counterparty = tx.counterparty,
                    raw_sms = tx.rawSms,
                    timestamp = tx.timestamp
                )
            )
            if (response.isSuccessful && response.body()?.success == true) {
                dao.updateStatus(tx.id, PendingTransaction.STATUS_SUCCESS)
                true
            } else {
                val error = response.body()?.message ?: "HTTP ${response.code()}"
                dao.incrementRetry(tx.id, error)
                false
            }
        } catch (e: Exception) {
            dao.incrementRetry(tx.id, e.message)
            false
        }
    }

    suspend fun clearOldSuccess() {
        val sevenDaysAgo = System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000L
        dao.deleteOldSuccess(sevenDaysAgo)
    }

    companion object {
        @Volatile
        private var INSTANCE: TransactionRepository? = null

        fun getInstance(context: Context): TransactionRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = TransactionRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
