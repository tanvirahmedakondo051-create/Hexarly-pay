package com.hexarlypay.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.Configuration
import androidx.work.WorkManager
import com.hexarlypay.app.worker.SyncWorker

class HexarlyPayApp : Application(), Configuration.Provider {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Schedule periodic sync (battery friendly)
        SyncWorker.enqueuePeriodic(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "hexarly_sync",
                "Hexarly Pay Sync",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when transactions are being synced"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
