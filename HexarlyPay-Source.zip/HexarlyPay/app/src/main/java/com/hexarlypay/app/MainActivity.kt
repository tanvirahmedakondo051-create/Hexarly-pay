package com.hexarlypay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.hexarlypay.app.ui.dashboard.DashboardScreen
import com.hexarlypay.app.ui.onboarding.OnboardingScreen
import com.hexarlypay.app.ui.setup.SetupScreen
import com.hexarlypay.app.ui.theme.HexarlyPayTheme
import com.hexarlypay.app.util.PreferenceHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = PreferenceHelper(this)
        val startDestination = when {
            !prefs.isOnboardingDone() -> "onboarding"
            !prefs.hasApiKey() -> "setup"
            else -> "dashboard"
        }

        setContent {
            HexarlyPayTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(
                        navController = navController,
                        startDestination = startDestination
                    ) {
                        composable("onboarding") {
                            OnboardingScreen(
                                onFinished = {
                                    prefs.setOnboardingDone()
                                    navController.navigate("setup") {
                                        popUpTo("onboarding") { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable("setup") {
                            SetupScreen(
                                onSetupComplete = {
                                    navController.navigate("dashboard") {
                                        popUpTo("setup") { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable("dashboard") {
                            DashboardScreen(
                                onOpenSetup = {
                                    navController.navigate("setup")
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
