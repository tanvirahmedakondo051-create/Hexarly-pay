package com.hexarlypay.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(tx: PendingTransaction): Long

    @Query("SELECT * FROM pending_transactions WHERE status = 'PENDING' OR status = 'FAILED' ORDER BY timestamp ASC LIMIT 50")
    suspend fun getPending(): List<PendingTransaction>

    @Query("SELECT * FROM pending_transactions ORDER BY timestamp DESC LIMIT 100")
    fun getRecentFlow(): Flow<List<PendingTransaction>>

    @Query("SELECT * FROM pending_transactions ORDER BY timestamp DESC LIMIT 100")
    suspend fun getRecent(): List<PendingTransaction>

    @Query("UPDATE pending_transactions SET status = :status, lastError = :error WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, error: String? = null)

    @Query("UPDATE pending_transactions SET retryCount = retryCount + 1, status = 'FAILED', lastError = :error WHERE id = :id")
    suspend fun incrementRetry(id: Long, error: String?)

    @Query("SELECT COUNT(*) FROM pending_transactions WHERE status = 'PENDING' OR status = 'FAILED'")
    fun pendingCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM pending_transactions WHERE status = 'SUCCESS' AND timestamp >= :todayStart")
    fun todaySuccessCountFlow(todayStart: Long): Flow<Int>

    @Query("DELETE FROM pending_transactions WHERE status = 'SUCCESS' AND timestamp < :before")
    suspend fun deleteOldSuccess(before: Long)

    @Query("DELETE FROM pending_transactions")
    suspend fun clearAll()
}
