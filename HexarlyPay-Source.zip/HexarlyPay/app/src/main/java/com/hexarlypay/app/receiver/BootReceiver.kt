package com.hexarlypay.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hexarlypay.app.worker.SyncWorker

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Re-schedule periodic sync after reboot
            SyncWorker.enqueuePeriodic(context)
        }
    }
}
