# Hexarly Pay – Android App

**Fully optimized SMS-to-Dashboard sync app for Bangladesh MFS (bKash, Nagad, Rocket etc.)**

Website: https://hexaarlypay.xyz

## Features
- Real-time SMS detection for supported providers
- Offline queue (Room DB) → auto sync when internet returns
- **Start Sync** button for manual trigger
- Extremely battery & CPU friendly (no polling, pre-compiled regex, WorkManager constraints)
- Professional Material 3 UI
- Dark mode support

## How to Build & Run

1. Install **Android Studio** (Hedgehog or newer recommended)
2. Open this folder as a project
3. Wait for Gradle sync
4. Connect your phone (USB debugging on) or use emulator
5. Click **Run** ▶️

## First Launch
1. Grant SMS permission
2. Enter your API Key (from hexaarlypay.xyz dashboard)
3. (Optional) Disable battery optimization for reliable background sync

## API Endpoint
The app sends POST requests to:
```
https://hexaarlypay.xyz/api/v1/transactions/sync
```
Header: `X-API-Key: your_key`

Body example:
```json
{
  "provider": "bkash",
  "amount": "500.00",
  "trx_id": "ABC123XYZ",
  "type": "IN",
  "balance": "1250.50",
  "raw_sms": "...",
  "timestamp": 1728825600000
}
```

## Supported Providers
- bKash
- Nagad
- Rocket
- + beta: mCash, CellFin, SureCash etc. (see assets/providers.json)

## Optimization Notes
- SMS Receiver does almost zero work on main thread
- Only matching senders are processed
- WorkManager only runs when network is available + battery not low
- Old successful transactions auto-cleaned after 7 days

---
Made for Hexarly Pay
